<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/4 15:55
 * Filename：Controller.php
 * 附加的资源重写
 */
require_once Run.'/includes/extend/resource/Config.php';
if(array_key_exists($route,$resource_rewrite)) {
	$resource=Run.'/includes/extend/resource/Library/'.$resource_rewrite[$route];
	if(file_exists($resource)&&!is_dir($resource)) {
		include($resource);
		die();
	}
}