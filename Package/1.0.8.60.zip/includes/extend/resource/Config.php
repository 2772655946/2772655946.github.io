<?php
$resource_rewrite=[
'get_login_code.jpg'=>'code.php',
];