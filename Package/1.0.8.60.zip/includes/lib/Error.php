<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/1 18:26
 * Filename：Error.php
 * 错误处理函数
 */
function CatchError() {
	$error=func_get_args();
	if(is_array($error)) {
		$msg='['.date("Y-m-d H:i:s").'] '.$error[0].' in '.$error[2].' on line '.$error[1]."\n";
		put_error_log(Run."/Api_mac/Api_error/".date("Y-m-d").".log",$msg,true);
		if(Debugging) {
			$GLOBALS['error_list'][]=$msg;
		}
	}
}
function HandlError() {
	if ($error = func_get_args()) {
		unset($error[4]);
		if($error[0]!==8) {
			CatchError($error[1],$error[3],$error[2]);
		}
	}
}
function put_error_log($route,$contents,$cover=false) {
	$fp = fopen($route,($cover?"a":"w"));
	if (flock($fp, LOCK_EX)) {
		fwrite($fp,$contents);
		flock($fp , LOCK_UN);
	} else {
		return false;
	}
	fclose($fp);
	return true;
}