<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/1 18:02
 * Filename：View.php
 * 程序底层配置
 */
if(!defined('Index_TPL_DIR')) define('Index_TPL_DIR',Run);
//当程序异常停止时的处理方案。暂时找不到解决方法，先用这个
return [
	'view_suffix'   => ['html','htm'],
	//伪静态文件后缀
	'suffix_list'   => ['bak'],
	/**
	 * 该限制只有在设置运行目录后
	 * 并且在“templates”文件夹下才能生效
	**/
	'suffix_tpl'   => 'html',
	//原始的模板文件后缀
	'http_code'   => [
	404=>Run."/public/404.html",
	],
	/**
	 * 设置自定义错误页，可设置多个
	 * 可选常量有Run(程序根目录)、Index_TPL_DIR(当前使用的前台模板目录)
	 * 规则不存在或路径不存在时返回默认的错误页
	**/
	'http_empty'   => false,
	//只输出错误页，其他内容不会输出
	'Cooling_cue'   => json_encode(['code'=>400,'error'=>"Don't operate too fast, and Xiaojie can't keep up with your rhythm."]),
	//接口达到每m秒请求n次的限制后返回的内容
	'QPS'   => json_encode(['code'=>400,'error'=>"Server Busy!"]),
	//QPS提示
	'api_conf'=>[
		'version' => '1',
		'request' => 'GET/POST',
		'returns' => 'JSON',
		'type' => ['string','int','txt','array','bool'],
	],
];