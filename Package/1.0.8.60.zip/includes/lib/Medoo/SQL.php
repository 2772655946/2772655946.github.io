<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/1 11:58
 * Filename：SQL.php
 * 数据库配置文件
 */
namespace lib\Medoo;
use lib\Medoo\Medoo;
class SQL {
	/**
	* @return Medoo PDO操作类
	*/
	public static function DB($config) {
		return new Medoo([
		'database_type' => 'mysql',
		'database_name' => $config['dbname'],
		'server' => $config['host'],
		'username' => $config['user'],
		'password' => $config['pwd'],
		'charset' => 'utf8',
		'port' => $config['port'],
		'prefix' => $config['prefix'],
		]);
	}
}