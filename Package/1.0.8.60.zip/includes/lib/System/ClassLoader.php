<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/1 18:31
 * Filename：ClassLoader.php
 * 类的自动加载
 */
function class_auto_loader($file_name) {
	if ($file_name) {
		if(strstr($file_name,'\\')) {
			$file_name = str_replace('\\', '/', $file_name);
		}
		$list=[
			Run.'/includes/'.$file_name.'.php',
			Run.'/includes/'.$file_name.'.clss.php',
			Run.'/Api_mac/Api_class/'.$file_name.'.php',
			Run.'/Api_mac/Api_class/'.$file_name.'.class.php',
		];
		foreach($list as $v) {
			if(file_exists($v)&&is_file($v)) {
				require_once $v;
				break;
			}
		}
	}
}