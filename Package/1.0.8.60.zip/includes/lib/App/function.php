<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/1 19:57
 * Filename：function.php
 * 公共函数库
 */


function get_url_http() {
	if(empty($_SERVER["REQUEST_SCHEME"])) {
		return strpos(strtolower($_server['server_protocol']),'https')  === false ? 'http' : 'https';
	} else {
		return $_SERVER["REQUEST_SCHEME"];
	}
}

function get_host($url,$stop=false) {
	$url=parse_url(strtolower(trim($url)));
	if(empty($url["host"])) {
		return $stop?$url["path"]:get_host("http://".$url["path"],true);
	} else {
		return $stop?$url["host"]:get_host("http://".$url["host"],true);
	}
}