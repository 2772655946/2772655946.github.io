<?php
namespace lib\Controller;
class Index {
	public function __construct($array) {
		$this->Mo=$array;
	}
	public function search() {
		global $DB;
		if(empty($_REQUEST['search'])) {
			$api_list = $DB->select('api', '*');
			return $this->list($api_list);
		} else {
			$api_list=$DB->select("api", "*", [
				"name[~]" => $_REQUEST['search']
			]);
			if(count($api_list)==0) {
				return '<div class="col-sm-12">
            <a target="" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="#">
                <div class="block-content">
                    <div class="h4 push-5">API不存在</div>
                    <p class="text-muted">没有找到相关的API，请换个关键词试试，若有想添加的API请联系站长进行咨询！！</p>
                </div>
            </a>
        </div>';
			} else {
				return $this->list($api_list);
			}
		}
	}
	public function list($api_list) {
		global $conf;
		$api_list=\JieAdmin\System::is_true($conf['sort'])==true?array_reverse($api_list):$api_list;
		$return='';
		foreach($api_list as $k=>$v) {
			$doc_url=\JieAdmin\System::get_doc_url($v);
			$return.='<div class="col-sm-4">
            <a target="_blank" class="block block-link-hover2 ribbon ribbon-modern ribbon-';
			if($v['status']=="ok") {
				$status='success';
			} else if($value['status']=="no") {
				$status='danger';
			} else if($value['status']=="rep") {
				$status='warning';
			}
			$return.=$status.'" href="'.$doc_url.'">
                <div class="ribbon-box font-w600">调用：'.$v["call_total"].'</div>
                <div class="block-content">
                    <div class="h4 push-5">'.$v["name"].'</div>
                    <p class="text-muted text-truncate">'.$v["briefing"].'</p>
                </div>
            </a>
        </div>';
		}
		return $return;
	}
}