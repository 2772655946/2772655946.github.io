<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/14 20:09
 * Filename：dome.php
 * 接口例子
 */

$data=[
	'code'=>200,
	'data'=> [
		'time'=>time(),
		'msg'=>$_GET['msg']?:'你好，世界！',
		'Tips'=>'Hello，World！'
	]
];
echo json_encode($data,320);