<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/8/11 15:03
 * Filename：dome.php
 * 手动调用统计使用方法
 */

if(empty($_GET['msg'])){
	die(json_encode(['code'=>-1,'error'=>'Msg is Null！'],320));
}
set_api_call();//调用统计
if(mt_rand(1,10)==5){
	die(json_encode(['code'=>200,'msg'=>'ok！'],320));
	//调用次数+1
}else{
	die(json_encode(['code'=>200,'msg'=>'no！'],320));
	unset_api_call();
	//撤销统计
}