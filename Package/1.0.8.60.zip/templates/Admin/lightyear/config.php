<?php
return [
	"name"=>"lightyear v4",
	"version"=>"1.0.0",
	"author"=>"小杰"
];