CREATE TABLE IF NOT EXISTS `{prefix}admin` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `subtitle` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `sort` text NOT NULL,
  `inform` text NOT NULL,
  `qq` varchar(10) NOT NULL,
  `qun` text NOT NULL,
  `mail` text NOT NULL,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `{prefix}admin` (`id`, `name`, `subtitle`, `description`, `keywords`, `sort`, `inform`, `qq`, `qun`, `mail`, `user`, `pass`, `date`) VALUES
(1, '小杰API', '免费接口调用服务平台', '小杰API是小杰免费提供API数据接口调用服务平台 - 我们致力于为用户提供稳定、快速的免费API数据接口服务。', '小杰API,小杰API-免费接口调用平台,免费接口调用平台,API,免费API,聚合数据,在线API,API接口,免费api接口平台,免费接口调用平台,机器人API', 'true', '', '2772655946', 'https://jq.qq.com/?_wv=1027&k=er3EvTIn', 'xiaojieapi@vip.qq.com', 'admin', '$2y$10$LqrlTVM8tTWyEns5UHHySe3ngwIslVMzTgZq/euInUaGBzlJHhtw2', '2021-03-20');
CREATE TABLE IF NOT EXISTS `{prefix}api` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `briefing` text NOT NULL,
  `keyword` text NOT NULL,
  `version` int(11) DEFAULT NULL,
  `url` text NOT NULL,
  `status` text NOT NULL,
  `consequence` text NOT NULL,
  `announcement` text NOT NULL,
  `appid` text NOT NULL,
  `request` text NOT NULL,
  `returns` text NOT NULL,
  `add_time` int(128) NOT NULL,
  `update_time` int(128) NOT NULL,
  `call_total` varchar(128) DEFAULT NULL,
  `call_day` varchar(128) DEFAULT NULL,
  `request_data` text,
  `return_data` text,
  `code_data` text,
  `Request_Instance` text,
  `example` text
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
INSERT INTO `{prefix}api` (`id`, `name`, `briefing`, `keyword`, `version`, `url`, `status`, `consequence`, `announcement`, `appid`, `request`, `returns`, `add_time`, `update_time`, `call_total`, `call_day`, `request_data`, `return_data`, `code_data`, `Request_Instance`, `example`) VALUES
(1, 'Dome', '这是一个测试接口', '', 1, 'dome', 'ok', '{"code":200,"data":{"time":1628587415,"msg":"你好，世界！","Tips":"Hello，World！"}}', '', '2000D', 'GET/POST', 'JSON', 1628583201, 1628702806, '0', '0', '{&quot{sil}list&quot{sil}:[[&quot{sil}msg&quot{sil},&quot{sil}true&quot{sil},&quot{sil}string&quot{sil},&quot{sil}\\u8bf7\\u6c42\\u5185\\u5bb9&quot{sil}]],&quot{sil}num&quot{sil}:1}', '{&quot{sil}list&quot{sil}:[[&quot{sil}code&quot{sil},&quot{sil}int&quot{sil},&quot{sil}\\u72b6\\u6001\\u7801&quot{sil}],[&quot{sil}data&quot{sil},&quot{sil}array&quot{sil},&quot{sil}\\u6570\\u636e\\u5217\\u8868&quot{sil}],[&quot{sil}time&quot{sil},&quot{sil}int&quot{sil},&quot{sil}\\u65f6\\u95f4\\u6233&quot{sil}],[&quot{sil}msg&quot{sil},&quot{sil}string&quot{sil},&quot{sil}\\u63d0\\u4ea4\\u5185\\u5bb9&quot{sil}],[&quot{sil}Tips&quot{sil},&quot{sil}string&quot{sil},&quot{sil}\\u63d0\\u793a\\u5185\\u5bb9&quot{sil}]],&quot{sil}num&quot{sil}:5}', '{&quot{sil}list&quot{sil}:[[&quot{sil}200&quot{sil},&quot{sil}string&quot{sil},&quot{sil}\\u8bf7\\u6c42\\u6210\\u529f&quot{sil}]],&quot{sil}num&quot{sil}:1}', NULL, NULL),
(2, '调用统计', '调用统计的用法', '', 1, 'statistics', 'ok', '', '', 'FA940', 'GET/POST', 'JSON', 1628665623, 1628665623, '0', '0', NULL, NULL, NULL, NULL, NULL);
CREATE TABLE IF NOT EXISTS `{prefix}apicall` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `json` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `{prefix}skimpv` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `json` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
INSERT INTO `{prefix}skimpv` (`id`, `date`, `json`) VALUES
(4, '2021-10-03', '{"01":42}');
CREATE TABLE IF NOT EXISTS `{prefix}system` (
  `id` int(11) NOT NULL,
  `api` text NOT NULL COMMENT '。',
  `apicall` text NOT NULL,
  `normal` text NOT NULL,
  `anomaly` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `{prefix}system` (`id`, `api`, `apicall`, `normal`, `anomaly`) VALUES
(1, '2', '0', '2', '0');
ALTER TABLE `{prefix}admin`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `{prefix}api`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `{prefix}apicall`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `{prefix}skimpv`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `{prefix}system`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `{prefix}admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
ALTER TABLE `{prefix}api`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
ALTER TABLE `{prefix}apicall`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
ALTER TABLE `{prefix}skimpv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
ALTER TABLE `{prefix}system`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;