<?php
if (version_compare(PHP_VERSION, '7.3.0', '<')) {
	die('require PHP => 7.3 !');
}
if(!file_exists('./Api_mac/Api_set/install.lock')&&!$_GET['q']) {
	die('<a href="/admin">请先安装！</a>');
}
define('in_Inside',true);
include('./public/index.php');