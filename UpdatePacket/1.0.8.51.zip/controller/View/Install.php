<?php
use lib\System\Rear;
class Install{
	public function __construct() {
		$this->Mo=new Rear();
		//不调用这个类会导致程序运行异常
		if($this->Mo->is_post()) {
			//如果是POST请求则视为提交数据
			$this->Mo->Api();
			//交给View外的Admin处理
		}
	}
	public function install() {
		$php_version=substr(PHP_VERSION,0,3);
		$php_version_color=$php_version>="7.3"?"success":"danger";
		$this->Mo->set_var('php_version','<span class="badge badge-'.$php_version_color.'">'.$php_version.'</span>');
		$this->check('sg_load');
		$this->check('file_get_contents');
		$this->check('curl_exec');
	}
	private function check($function_name) {
		$status=function_exists($function_name);
		$this->Mo->set_var($function_name,'<span class="badge badge-'.($status==true?"success":"danger").'">'.($status==true?"可用":"不可用").'</span>');
	}
}