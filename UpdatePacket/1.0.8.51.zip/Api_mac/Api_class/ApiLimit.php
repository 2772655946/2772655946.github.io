<?php
/**
 * Author：小杰 QQ：2772655946
 * Creation：2021/5/26 10:19
 * Filename：ApiLimit.php
 * API请求限制类
 */
class ApiLimit {
	public $safe;
	//配置信息
	public function __construct($safe) {
		$this->cycle=$safe["cycle"];
		//访问周期(秒)
		$this->frequency=$safe["frequency"];
		//访问频率(次)
		$this->lockdown=$safe["lockdown"];
		//冷却时间(秒)
		$this->route=$safe["route"];
		//储存路径
		$this->ip=$this->ip();
		//用户ip
	}
	public function check() {
		if(file_exists($this->route)) {
			$ccdata=json_decode(file_get_contents($this->route),true);
			if(!is_array($ccdata)){
				unlink($this->route);
				return $this->check();
			}
			if($ccdata['list'][$this->ip]["lockdown"]) {
				//冷却中
				if($ccdata['list'][$this->ip]["lockdown_time"]>time()) {
					//冷却时间未到
					return true;
				} else {
					//冷却结束
					$ccdata['list'][$this->ip]["lockdown"]=false;
					unset($ccdata['list'][$this->ip]["lockdown_time"]);
					//删除无用变量
					$this->write($this->route,json_encode($ccdata));
					//保存数据
				}
			}
			global $safe;
			if($ccdata['list'][$this->ip]["bucket"][time()]>=$safe['qps_int']&&\JieAdmin\System::is_true($safe['qps'])){
				return 'QPS';
			}
			if($ccdata['list'][$this->ip]["end"]>time()&&$ccdata['list'][$this->ip]["frequency"]>=$this->frequency) {
				//超出最高访问限制
				$ccdata['list'][$this->ip]["frequency"]=0;
				$ccdata['list'][$this->ip]["start"]=0;
				$ccdata['list'][$this->ip]["end"]=0;
				$ccdata['list'][$this->ip]["lockdown"]=true;
				$ccdata['list'][$this->ip]["lockdown_time"]=time()+$this->lockdown;
				$this->write($this->route,json_encode($ccdata));
				//保存数据
				return true;
			} else {
				$this->monitor($ccdata);
				//监控
			}
		} else {
			$ccdata=array(
				'list'=>array(
				$this->ip=>array(
				    "bucket"=>array(),
				    "start"=>time(),
				    "end"=>time()+$this->cycle,
				    "frequency"=>1,
				    "lockdown"=>false,
			    )));
			$this->write($this->route,json_encode($ccdata));
			//初始化文件
		}
		return false;
	}
	public function monitor($ccdata=false) {
		if(!$ccdata) {
			$ccdata=json_decode(file_get_contents($this->route),true);
		}
		$time=time();
		$ccdata=$this->clear($ccdata,$time);
		$ccdata['list'][$this->ip]["bucket"][$time]+=1;
		if($ccdata['list'][$this->ip]["end"]<$time) {
			//数据过期
			$ccdata['list'][$this->ip]["start"]=$time;
			$ccdata['list'][$this->ip]["end"]=$time+$this->cycle;
			$ccdata['list'][$this->ip]["frequency"]+=1;
		} else {
			$ccdata['list'][$this->ip]["frequency"]+=1;
		}
		$this->write($this->route,json_encode($ccdata));
		//保存数据
	}
	public function clear($ccdata,$time) {
	$num=$ccdata['list'][$this->ip]["bucket"][$time];
	unset($ccdata['list'][$this->ip]["bucket"]);
	$ccdata['list'][$this->ip]["bucket"][$time]=$num;
	return $ccdata;
	}

	public function write($route,$contents,$cover=false) {
		$file_name=array_reverse(explode("/",$route))[0];
		$file_route=$route;
		$route=str_replace($file_name,"",$route);
		if(is_dir($route)==false) {
			mkdir($route,0777,true);
		}
		$fp = fopen($file_route,($cover?"a":"w"));
		if (flock($fp, LOCK_EX)) {
			fwrite($fp,$contents);
			flock($fp , LOCK_UN);
		} else {
			return false;
		}
		fclose($fp);
		return true;
	}
	public function ip() {
		if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
			$ip = getenv('HTTP_CLIENT_IP');
		} else if (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
			$ip = getenv('HTTP_X_FORWARDED_FOR');
		} else if (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
			$ip = getenv('REMOTE_ADDR');
		} else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		$res =  preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
		return $res;
	}
}