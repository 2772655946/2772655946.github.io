<?php
use lib\System\Rear;
class Index{
	public function __construct($DB) {
		$this->DB=$DB;
		$this->Mo=new Rear($DB);
		if($this->Mo->is_post()||FILE_NAME=='search') {
			$this->Mo->Api();
			//交给View外的Admin处理
		}
	}
	public function index() {
		global $conf;
		$api_list = $this->DB->select('api', '*');
		$system = $this->DB->get('system', '*', ['id' => 1]);
		$api_list=is_true($conf['sort'])==true?array_reverse($api_list):$api_list;
		$this->Mo->set_var('system',$system);
		foreach($api_list as $k=>$v){
			$api_list[$k]['doc_url']=get_doc_url($v);
		}
		$this->Mo->set_var('api_list',$api_list);
		$this->Mo->set_var('day_call',(get_day_call()?:0));
		//今日调用量
	}
	public function doc() {
		global $doc_data;
		//因为内部验证接口文档链接需要查询接口添加时间。所以内部已经查询了一次信息，直接引入变量就可以，没必要重新查询一次。
		$doc_data['url']=str_replace(['{host}','{http}'],[$_SERVER['HTTP_HOST'],get_url_http().'://'],$doc_data['url']);
		if(substr($doc_data['url'],0,4)!="http"){
			$doc_data['url']="/api/v".$doc_data['version']."/get/".$doc_data['url'];
			$this->Mo->set_var('http',get_url_http().'://'.$_SERVER['HTTP_HOST']);
		}
		$request_data=json_decode(htmlspecialchars_decode($doc_data['request_data']),true);
		if(is_array($request_data)){
		}else{
			$request_data['list']=[];
		}
		$this->Mo->set_var('request_data',$request_data);
		$return_data=json_decode(htmlspecialchars_decode($doc_data['return_data']),true);
		if(is_array($return_data)){
		}else{
			$return_data['list']=[];
		}
		$this->Mo->set_var('return_data',$return_data);
		$code_data=json_decode(htmlspecialchars_decode($doc_data['code_data']),true);
		if(is_array($code_data)){
		}else{
			$code_data['list']=[];
		}
		$this->Mo->set_var('code_data',$code_data);
		$doc_data['example']=$doc_data['example']?:'管理员没有填写示例代码！';
		$doc_data['Request_Instance']=$doc_data['Request_Instance']?('?'.$doc_data['Request_Instance']):'';
		$this->Mo->set_var('doc',$doc_data);
	}

}