<?php
namespace lib\Controller;
class Admin {
	public function __construct($array) {
		$this->Mo=$array;
		$this->DB=$this->Mo->DB;
	}
	public function login() {
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		$code=$_POST['code'];
		$remember=$_POST['remember']==="on"?true:false;
		if(FILE_NAME!="login"&&!isset($_POST['remember'])) {
			return ['code'=>400,'msg'=>'登录状态已失效，请重新登录！'];
		} else if($_SESSION["code_error"]>=5) {
			if((time()-$_SESSION['code_time'])>=(60*30)) {
				$_SESSION['code_error']=0;
				return ['code'=>400,'msg'=>'操作过期，请重试！'];
			} else {
				return ['code'=>400,'msg'=>'操作过于频繁！'];
			}
		} else if(empty($user)) {
			return ['code'=>-1,'msg'=>'账号不能为空！'];
		} else if(mb_strlen($user)<2) {
			return ['code'=>-2,'msg'=>'账号长度不能小于2！'];
		} else if(mb_strlen($user)>18) {
			return ['code'=>-3,'msg'=>'账号长度不能大于18！'];
		} else if(empty($pass)) {
			return ['code'=>-4,'msg'=>'密码不能为空！'];
		} else if(mb_strlen($pass)<6) {
			return ['code'=>-5,'msg'=>'密码长度不能小于6！'];
		} else if(mb_strlen($pass)>16) {
			return ['code'=>-6,'msg'=>'密码长度不能大于16！'];
		} else if(empty($code)&&$code!="0") {
			return ['code'=>-7,'msg'=>'验证码不能为空！'];
		} else if($_SESSION["code"]!=$_POST["code"]) {
			$_SESSION['code_error']+=1;
			$_SESSION['code_time']=time();
			return ['code'=>-8,'msg'=>'验证码输入有误，请重新输入！'];
		} else if($this->Mo->login($user,$pass,$remember)) {
			return ['code'=>200,'msg'=>'登录成功，欢迎回来！'];
		} else {
			return ['code'=>201,'msg'=>'账号或密码错误！'];
		}
	}
	public function config() {
		$sort=$_POST['sort'];
		$date=$_POST['date'];
		$inform=$_POST['inform'];
		$name=$_POST['name'];
		$subtitle=$_POST['subtitle'];
		$keywords=$_POST['keywords'];
		$description=$_POST['description'];
		if(empty($sort)) {
			return ['code'=>-1,'msg'=>'排序方式不能为空！'];
		} else if(empty($date)) {
			return ['code'=>-2,'msg'=>'建站日期不能为空！'];
		} else if(empty($name)) {
			return ['code'=>-3,'msg'=>'网站名称不能为空！'];
		} else if(empty($subtitle)) {
			return ['code'=>-4,'msg'=>'网站副标题不能为空！'];
		} else {
			$admin_data_array=[
			'sort'=>$sort,
			'date'=>$date,
			'inform'=>htmlspecialchars($inform),
			'name'=>$name,
			'subtitle'=>$subtitle,
			'keywords'=>$keywords,
			'description'=>$description,
			];
			$this->DB->update("admin", $admin_data_array, ["id" => 1]);
			if(!is_array($this->DB->errorInfo)) {
				return ['code'=>200,'msg'=>'修改成功！'];
			} else {
				return ['code'=>-1,'msg'=>'修改失败，原因：'.$this->DB->error];
			}
		}
	}
	public function contact() {
		$qq=$_POST['qq'];
		$mail=$_POST['mail'];
		$qun=$_POST['qun'];
		if(empty($qq)) {
			return ['code'=>-1,'msg'=>'管理员QQ不能为空！'];
		} else {
			$admin_data_array=[
			'qq'=>$qq,
			'mail'=>$mail,
			'qun'=>$qun,
			];
			$this->DB->update("admin", $admin_data_array, ["id" => 1]);
			if(!is_array($this->DB->errorInfo)) {
				return ['code'=>200,'msg'=>'修改成功！'];
			} else {
				return ['code'=>-1,'msg'=>'修改失败，原因：'.$this->DB->error];
			}
		}
	}
	public function user() {
		$user=$_POST['user'];
		$pass=$_POST['pass'];
		if(empty($user)) {
			return ['code'=>-1,'msg'=>'管理账号不能为空！'];
		} else if(mb_strlen($user)<2) {
			return ['code'=>-2,'msg'=>'账号长度不能小于2！'];
		} else if(mb_strlen($user)>18) {
			return ['code'=>-3,'msg'=>'账号长度不能大于18！'];
		} else {
			$admin_data_array['user']=$user;
			if(!empty($pass)) {
				if(mb_strlen($pass)<6) {
					return ['code'=>-4,'msg'=>'密码长度不能小于6！'];
				} else if(mb_strlen($pass)>16) {
					return ['code'=>-5,'msg'=>'密码长度不能大于16！'];
				}
				$admin_data_array['pass']=password_hash(htmlspecialchars($pass),PASSWORD_DEFAULT);
			}
			$this->DB->update("admin", $admin_data_array, ["id" => 1]);
			if(!is_array($this->DB->errorInfo)) {
				$this->Mo->out_login();
				//退出登录，这里很重要
				return ['code'=>200,'msg'=>'修改成功！'];
			} else {
				return ['code'=>-1,'msg'=>'修改失败，原因：'.$this->DB->error];
			}
		}
	}
	public function firset() {
		$firewall=$_POST['firewall'];
		if(empty($firewall)) {
			return ['code'=>-1,'msg'=>'非法请求！'];
		}
		$set_array=[
		"firewall"=>$firewall,
		];
		if(put_system_data('safe',$set_array)) {
			return ['code'=>200,'msg'=>'修改成功！'];
		} else {
			return ['code'=>-2,'msg'=>'修改失败，请检查是否赋予读写权限！'];
		}
	}
	public function apilimit() {
		$apilimit=$_POST['apilimit'];
		$qps=$_POST['qps'];
		$qps_int=$_POST['qps_int'];
		$cycle=$_POST['cycle'];
		$frequency=$_POST['frequency'];
		$lockdown=$_POST['lockdown'];
		if(empty($apilimit)||empty($qps)) {
			return ['code'=>-1,'msg'=>'非法请求！'];
		}
		if($apilimit==="true") {
			if(empty($cycle)) {
				return ['code'=>-1,'msg'=>'访问周期不能为空！'];
			} else if(empty($frequency)) {
				return ['code'=>-2,'msg'=>'访问频率不能为空！'];
			} else if(empty($lockdown)) {
				return ['code'=>-3,'msg'=>'冷却时间不能为空！'];
			} else if(empty($qps_int)) {
				return ['code'=>-4,'msg'=>'QPS不能为空！'];
			}
		}
		$set_array=[
		"apilimit"=>$apilimit,
		"qps"=>$qps,
		"qps_int"=>(int)$qps_int,
		"cycle"=>(int)$cycle,
		"frequency"=>(int)$frequency,
		"lockdown"=>(int)$lockdown,
		];
		if(put_system_data('safe',$set_array)) {
			return ['code'=>200,'msg'=>'修改成功！'];
		} else {
			return ['code'=>-2,'msg'=>'修改失败，请检查是否赋予读写权限！'];
		}
	}
	public function tplswitch() {
		$m_i=$_POST['m_i'];
		$pc_i=$_POST['pc_i'];
		$m_a=$_POST['m_a'];
		$pc_a=$_POST['pc_a'];
		if(empty($m_i)||empty($m_a)||empty($pc_i)||empty($pc_a)) {
			return ['code'=>-1,'msg'=>'非法请求！'];
		}
		$tpl_array=[
		"m_i"=>$m_i,
		"pc_i"=>$pc_i,
		"m_a"=>$m_a,
		"pc_a"=>$pc_a,
		];
		if(put_system_data('templates',$tpl_array)) {
			return ['code'=>200,'msg'=>'修改成功！'];
		} else {
			return ['code'=>-2,'msg'=>'修改失败，请检查是否赋予读写权限！'];
		}
	}
	public function listapi() {
		$api_list = $this->DB->select('api', '*');
		return ['code'=>200,'rows'=>$api_list];
	}
	public function routeapi() {
		$api_rule=$_POST['api_rule'];
		$api_route=$_POST['api_route'];
		$doc_rule=$_POST['doc_rule'];
		$doc_route=$_POST['doc_route'];
		if(empty($api_rule)) {
			return ['code'=>-1,'msg'=>'请求路径不能为空！'];
		} else if(empty($api_route)) {
			return ['code'=>-2,'msg'=>'原始路径不能为空！'];
		} else if(empty($doc_rule)) {
			return ['code'=>-3,'msg'=>'接口文档请求路径不能为空！'];
		} else if(empty($doc_route)) {
			return ['code'=>-4,'msg'=>'校验规则不能为空！'];
		}
		$api_array=[
		"api_rule"=>$api_rule,
		"api_route"=>$api_route,
		"doc_rule"=>$doc_rule,
		"doc_route"=>$doc_route,
		];
		if(put_system_data('Api',$api_array)) {
			return ['code'=>200,'msg'=>'修改成功！'];
		} else {
			return ['code'=>-5,'msg'=>'修改失败，请检查是否赋予读写权限！'];
		}
	}
	public function delete_api() {
		$id=$_POST['id'];
		if(empty($id)) {
			return ['code'=>-1,'msg'=>'非法请求！'];
		}
		$doc_data = $this->DB->get('api', '*', ['id' => (int)$id]);
		if(!is_array($doc_data)) {
			return ['code'=>-2,'msg'=>'数据异常！'];
		}
		$this->DB->delete('api', ['id' => $id]);
		if(!is_array($this->DB->errorInfo)) {
			$data = $this->DB->get('system', '*', ['id' => 1]);
			unset($data['id']);
			$data['api']-=1;
			if($doc_data['status']=="ok"){
				$data['normal']-=1;
			}else{
				$data['anomaly']-=1;
			}
			$this->DB->update("system", $data);
			if(!is_array($this->DB->errorInfo)) {
				return ['code'=>200,'msg'=>'删除成功！'];
			} else {
				return ['code'=>-1,'msg'=>'删除失败，原因：'.$this->DB->error];
			}
		} else {
			return ['code'=>-1,'msg'=>'删除失败，原因：'.$this->DB->error];
		}
	}
	public function api_keyword_fill() {
		$name=$_POST['name'];
		if(empty($name)) {
			return ['code'=>-1,'msg'=>'非法请求！'];
		}
		$keyword_data = strToUtf8(file_get_contents('http://suggestion.baidu.com/su?from=1013843g&wd='.$name.'&json=1'));
		preg_match("/\((.*?)\);/",$keyword_data,$keyword_data);
		$keyword_data=json_decode($keyword_data[1],true);
		foreach($keyword_data['s'] as $v) {
			similar_text($name,$v,$percentage);
			if($percentage>=60) {
				$keyword.=$v.',';
			}
		}
		if(empty($keyword)) {
			return ['code'=>-2,'msg'=>'没有找到相关记录！'];
		}
		return ['code'=>200,'msg'=>'自动填充成功！','keyword'=>$keyword];
	}
	public function addapi() {
		global $View;
		$name=$_POST['name'];
		$briefing=$_POST['briefing'];
		$version=$_POST['version'];
		$keyword=$_POST['keyword'];
		$status=$_POST['status'];
		$url=$_POST['url'];
		$request=$_POST['request'];
		$returns=$_POST['returns'];
		$announcement=$_POST['announcement'];
		$consequence=$_POST['consequence'];
		if(empty($name)) {
			return ['code'=>-1,'msg'=>'请输入接口名称！'];
		} else if(empty($briefing)) {
			return ['code'=>-2,'msg'=>'请输入接口介绍！'];
		} else if(empty($status)) {
			return ['code'=>-3,'msg'=>'请输入接口状态！'];
		} else if(empty($url)) {
			return ['code'=>-4,'msg'=>'请输入接口地址！'];
		}
		$api_data=[
		'name'=>$name,
		'briefing'=>$briefing,
		'version'=>$version?:$View['api_conf']['version'],
		'keyword'=>$keyword,
		'status'=>$status,
		'url'=>$url,
		'request'=>$request?:$View['api_conf']['request'],
		'returns'=>$returns?:$View['api_conf']['returns'],
		'announcement'=>$announcement,
		'consequence'=>$consequence,
		'call_day'=>0,
		'call_total'=>0,
		'update_time'=>time(),
		'add_time'=>time(),
		'appid'=>static::appid(),
		];
		$this->DB->insert('api',$api_data);
		if(!is_array($this->DB->errorInfo)) {
			$data = $this->DB->get('system', '*', ['id' => 1]);
			unset($data['id']);
			$data['api']+=1;
			if($status=="ok"){
				$data['normal']+=1;
			}else{
				$data['anomaly']+=1;
			}
			$this->DB->update("system", $data);
			if(!is_array($this->DB->errorInfo)) {
				return ['code'=>200,'msg'=>'添加成功！'];
			} else {
				return ['code'=>-5,'msg'=>'添加失败，原因：'.$this->DB->error];
			}
		} else {
			return ['code'=>-5,'msg'=>'添加失败，原因：'.$this->DB->error];
		}
	}
	public function editapi() {
		$id=$_GET['id'];
		$api_data = $this->DB->get('api', '*', ['id' => (int)$id]);
		if(empty($id)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$name=$_POST['name'];
		$briefing=$_POST['briefing'];
		$version=$_POST['version'];
		$keyword=$_POST['keyword'];
		$status=$_POST['status'];
		$url=$_POST['url'];
		$Request_Instance=$_POST['Request_Instance'];
		$request=$_POST['request'];
		$returns=$_POST['returns'];
		$announcement=$_POST['announcement'];
		$consequence=$_POST['consequence'];
		if(empty($name)) {
			return ['code'=>-1,'msg'=>'请输入接口名称！'];
		} else if(empty($briefing)) {
			return ['code'=>-2,'msg'=>'请输入接口介绍！'];
		} else if(empty($version)) {
			return ['code'=>-3,'msg'=>'请输入接口版本！'];
		} else if(empty($status)) {
			return ['code'=>-4,'msg'=>'请输入接口状态！'];
		} else if(empty($url)) {
			return ['code'=>-5,'msg'=>'请输入接口地址！'];
		} else if(empty($request)) {
			return ['code'=>-6,'msg'=>'请输入请求方式！'];
		} else if(empty($returns)) {
			return ['code'=>-7,'msg'=>'请输入返回格式！'];
		} else if(empty($consequence)) {
			return ['code'=>-8,'msg'=>'请输入返回结果！'];
		}
		$api_data=[
		'name'=>$name,
		'briefing'=>$briefing,
		'version'=>$version?:$View['api_conf']['version'],
		'keyword'=>$keyword,
		'status'=>$status,
		'url'=>$url,
		'Request_Instance'=>$Request_Instance,
		'request'=>$request?:$View['api_conf']['request'],
		'returns'=>$returns?:$View['api_conf']['returns'],
		'announcement'=>$announcement,
		'consequence'=>$consequence,
		'update_time'=>time(),
		'call_day'=>$api_data['call_day']?:0,
		'call_total'=>$api_data['call_total']?:0,
		];
		$this->DB->update('api',$api_data, ["id" => $id]);
		if(!is_array($this->DB->errorInfo)) {
			$data = $this->DB->get('system', '*', ['id' => 1]);
			unset($data['id']);
			if($api_data['status']!=$status){
				if($status=="ok"){
					$data['normal']+=1;
					$data['anomaly']-=1;
				}else{
					$data['anomaly']+=1;
					$data['normal']-=1;
				}
			}
			$this->DB->update("system", $data);
			if(!is_array($this->DB->errorInfo)) {
				return ['code'=>200,'msg'=>'修改成功！'];
			} else {
				return ['code'=>-9,'msg'=>'修改失败，原因：'.$this->DB->error];
			}
		} else {
			return ['code'=>-9,'msg'=>'修改失败，原因：'.$this->DB->error];
		}
	}
	public function req_save() {
		$id=$_GET['id'];
		$api_data = $this->DB->get('api', '*', ['id' => (int)$id]);
		if(empty($id)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$data=$_POST['data'];
		if(empty($data)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$data=where_data(json_decode($data));
		if(!is_array($data)) {
			return ['code'=>400,'msg'=>'数据异常！'];
		}
		$request_data=[
			'request_data'=>htmlspecialchars(json_encode(['list'=>$data,'num'=>count($data)])),
		];
		$this->DB->update("api", $request_data, ["id" => $id]);
		if(!is_array($this->DB->errorInfo)) {
			return ['code'=>200,'msg'=>'保存成功！'];
		} else {
			return ['code'=>-1,'msg'=>'保存失败，原因：'.$this->DB->error];
			}
	}
	public function ret_save() {
		$id=$_GET['id'];
		$api_data = $this->DB->get('api', '*', ['id' => (int)$id]);
		if(empty($id)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$data=$_POST['data'];
		if(empty($data)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$data=where_data(json_decode($data));
		if(!is_array($data)) {
			return ['code'=>400,'msg'=>'数据异常！'];
		}
		$return_data=[
			'return_data'=>htmlspecialchars(json_encode(['list'=>$data,'num'=>count($data)])),
		];
		$this->DB->update("api", $return_data, ["id" => $id]);
		if(!is_array($this->DB->errorInfo)) {
			return ['code'=>200,'msg'=>'保存成功！'];
		} else {
			return ['code'=>-1,'msg'=>'保存失败，原因：'.$this->DB->error];
			}
	}
	public function code_save() {
		$id=$_GET['id'];
		$api_data = $this->DB->get('api', '*', ['id' => (int)$id]);
		if(empty($id)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$data=$_POST['data'];
		if(empty($data)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$data=where_data(json_decode($data));
		if(!is_array($data)) {
			return ['code'=>400,'msg'=>'数据异常！'];
		}
		$code_data=[
			'code_data'=>htmlspecialchars(json_encode(['list'=>$data,'num'=>count($data)])),
		];
		$this->DB->update("api", $code_data, ["id" => $id]);
		if(!is_array($this->DB->errorInfo)) {
			return ['code'=>200,'msg'=>'保存成功！'];
		} else {
			return ['code'=>-1,'msg'=>'保存失败，原因：'.$this->DB->error];
			}
		}
	public function Demonstration() {
		$id=$_GET['id'];
		$api_data = $this->DB->get('api', '*', ['id' => (int)$id]);
		if(empty($id)) {
			return ['code'=>400,'msg'=>'非法请求！'];
		}
		$example=$_POST['example'];
		$example_data=[
			'example'=>htmlspecialchars($example),
		];
		$this->DB->update("api", $example_data, ["id" => $id]);
		if(!is_array($this->DB->errorInfo)) {
			return ['code'=>200,'msg'=>'修改成功！'];
		} else {
			return ['code'=>-1,'msg'=>'修改失败，原因：'.$this->DB->error];
			}
	}
	private static function appid() {
	$md5_url=md5(mt_rand().time());
	$md5_data1=substr($md5_url,10,-21);
	$md5_data2=substr($md5_url,30,-1);
	$md5_data3=substr($md5_url,20,-11);
	$md5_data4=substr($md5_url,7,-24);
	$md5_data5=substr($md5_url,24,-7);
	$md5_data0=strtoupper($md5_data1.$md5_data2.$md5_data3.$md5_data4.$md5_data5);
	return $md5_data0;
	}
}