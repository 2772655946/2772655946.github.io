<?php
return [
	'1.0.8'=> [
		'5'=> ['CREATE TABLE `{prefix}admin` (`id` int(11) NOT NULL AUTO_INCREMENT,PRIMARY KEY (`id`)) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8;'],
	],
];