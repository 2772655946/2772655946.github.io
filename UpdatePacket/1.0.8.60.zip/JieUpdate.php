<?php
class JieUpdate{
	public function optimize(){
		return true;
	}
}