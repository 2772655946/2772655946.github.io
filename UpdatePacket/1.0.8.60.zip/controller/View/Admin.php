<?php
use lib\System\Rear;
class Admin {
	public function __construct($DB) {
		$this->DB=$DB;
		$this->Mo=new Rear($DB);
		if(FILE_NAME!=='login'&&!$this->Mo->is_login()) {
			//未登录
			$this->Mo->rewrite('login');
			//把模板源文件指向login
		}
		if($this->Mo->is_post()) {
			//如果是POST请求则视为提交数据
			$this->Mo->Api();
			//交给View外的Admin处理
		}
		$this->Mo->set_var('nick',$this->Mo->get_qq_nick());
		//获取QQ昵称[可选参数QQ号]
		$this->Mo->set_var('is_login',$this->Mo->is_login());
		$this->update_data=$this->Mo->check_update();
		//检查更新
		if(!$this->update_data['status']&&count($this->update_data)!=0){
			$this->Mo->set_var('not_cloud',true);
		}
		if (version_compare(version, $this->update_data['body']['version'], '<')&&!$_COOKIE['new_version']&&$this->Mo->is_login()) {
			//防止一直重复弹出
			setcookie("new_version",true, time()+(60*10));
			//设置有效期10分钟
			$this->Mo->set_var('new_version',true);
		}
		$this->Mo->set_var('update_data',$this->update_data);
	}
	public function login() {
		if($_GET['loginout']==="1") {
			//登出
			$this->Mo->set_var('Tips','您已成功退出登入！');
			//设置提示
			$this->Mo->out_login();
			//删除cookie
		}
		if($this->Mo->is_login()) {
			//已登陆
			$this->Mo->go_index();
			//转跳到首页
		}
	}
	public function index() {
		$system = $this->DB->get('system', '*', ['id' => 1]);
		//查询基础信息
		$this->Mo->set_var('system',$system);
		//设置变量
		$pv_today = static::get_chart_var(json_decode($this->DB->get('skimpv', '*', ['date' => date("Y-m-d")])['json'],true),5);
		//查询今日pv
		$this->Mo->set_var('pv_today',$pv_today);
		$pv_yesterday = static::get_chart_var(json_decode($this->DB->get('skimpv', '*', ['date' => date("Y-m-d",strtotime("-1 day"))])['json'],true),5);
		//查询昨日pv
		$this->Mo->set_var('pv_yesterday',$pv_yesterday);

		$api_today = static::get_chart_var(json_decode($this->DB->get('apicall', '*', ['date' => date("Y-m-d")])['json'],true),5);
		//查询今日调用量
		$this->Mo->set_var('api_today',$api_today);
	}
	public function firset() {
		$safe=\JieAdmin\System::get_system_data('safe');
		$this->Mo->set_var('safe',$safe);
		//设置变量
	}
	public function tplswitch() {
		$tpl_list=[
		'pc_i'=>$this->Mo->get_templates('Index','pc'),
		'pc_a'=>$this->Mo->get_templates('Admin','pc'),
		'm_i'=>$this->Mo->get_templates('Index','m'),
		'm_a'=>$this->Mo->get_templates('Admin','m'),
		];
		$this->Mo->set_var('tpl_list',$tpl_list);
	}
	public function apilimit() {
		return $this->firset();
	}
	public function routeapi() {
		global $Api_route_set;
		$this->Mo->set_var('system',$Api_route_set);
	}
	public function editapi() {
		global $View;
		if(empty($_GET['id'])) {
			return \JieAdmin\System::error(404);
		}
		$doc_data = $this->DB->get('api', '*', ['id' => $_GET['id']]);
		if(!is_array($doc_data)){
			return \JieAdmin\System::error(404);
		}
		$this->Mo->set_var('data',$doc_data);	
		$this->Mo->set_var('title',$doc_data['name']);
		$request_data=json_decode(htmlspecialchars_decode($doc_data['request_data']),true);
		if(!is_array($request_data)){
			$request_data['list']=[];
			$request_data['num']=0;
		}
		$this->Mo->set_var('request_data',$request_data);
		$return_data=json_decode(htmlspecialchars_decode($doc_data['return_data']),true);
		if(!is_array($return_data)){
			$return_data['list']=[];
			$return_data['num']=0;
		}
		$this->Mo->set_var('return_data',$return_data);
		$code_data=json_decode(htmlspecialchars_decode($doc_data['code_data']),true);
		if(!is_array($code_data)){
			$code_data['list']=[];
			$code_data['num']=0;
		}
		$this->Mo->set_var('code_data',$code_data);
		$this->Mo->set_var('type',$View['api_conf']['type']);
	}
	public function update() {
		if(empty($this->update_data['body']['version'])){
			$this->Mo->set_var('exit',true);
		}else if(version_compare(version, $this->update_data['body']['version'], '<')){
		}else{
			$this->Mo->set_var('Lock',true);
		}
	}
	public function cloud() {
		$cloud=\JieAdmin\System::get_system_data('templates');
		$this->Mo->set_var('cloud',$cloud);
		//设置变量
		$resource_cdn=\JieAdmin\System::get_system_data('CDN');
		$resource_cdn['resource_cdn']=json_decode($resource_cdn['resource_cdn'],true);
		if(!is_array($resource_cdn['resource_cdn'])){
			$resource_cdn['resource_cdn']=[];
		}
		foreach($resource_cdn['resource_cdn'] as $k=>$v){
			$cdn_list['list'][]=get_host($v);
		}
		$cdn_list['num']=count($resource_cdn['resource_cdn']);
		$this->Mo->set_var('cdn_list',$cdn_list);
		//设置变量
	}
	private static function get_chart_var($array,$num) {
		for ($i=0;$i<$num;$i++) {
			$date_list[]=date("Y-m-d H",strtotime("-".$i." hours"));
		}
		$date_list=array_reverse($date_list);
		foreach($date_list as $v) {
			$H=str_replace(array(date("Y-m-d").' ',date("Y-m-d",strtotime("-1 day").' ')),'',$v);
			$date.='"'.$H.'时",';
			if($array[$H]) {
				$chart.='"'.$array[$H].'",';
			} else {
				$chart.='"0",';
			}
		}
		return ['date'=>$date,'data'=>$chart];
	}
}