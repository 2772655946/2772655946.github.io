<?php
return [
	"name"=>"绿色简洁",
	"version"=>"1.0.1",
	"author"=>"未知"
];