<?php
define('Debugging',true);
//调试模式
define('gzip',false);
//开启gzip加密传输(一般情况下不用开启)
define('cookie_safe',true);
//cookie保护(一般不需要动)，修改此设置会导致已登录的用户退出登陆
define('system_safe_lock',true);
//当为true时，不设置运行目录程序无法运行
define('disable_update',false);
//当为true时，在线更新功能将失效
if(defined('in_Inside')) {
	$Run=$_SERVER['DOCUMENT_ROOT'];
} else {
	$Run='../';
}
//程序根目录
require $Run.'/includes/Common.php';
// 加载程序主体